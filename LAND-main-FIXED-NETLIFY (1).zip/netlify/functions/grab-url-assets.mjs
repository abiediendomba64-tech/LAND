import { crawlHtml } from '../lib/crawler.mjs';

function response(statusCode, body) {
  return {
    statusCode,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store',
      'x-content-type-options': 'nosniff',
    },
    body: JSON.stringify(body),
  };
}

export default async function handler(event) {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 204,
      headers: {
        'access-control-allow-origin': '*',
        'access-control-allow-methods': 'POST, OPTIONS',
        'access-control-allow-headers': 'content-type',
      },
      body: '',
    };
  }
  if (event.httpMethod !== 'POST') return response(405, { success: false, error: 'Method not allowed' });

  try {
    const body = JSON.parse(event.body || '{}');
    const result = await crawlHtml(body.url || body.targetUrl, {
      timeoutMs: Math.min(Math.max(Number(body.timeoutMs) || 15000, 3000), 20000),
      maxBytes: Math.min(Math.max(Number(body.maxBytes) || 5 * 1024 * 1024, 100_000), 8 * 1024 * 1024),
      maxAssets: Math.min(Math.max(Number(body.maxAssets) || 500, 1), 1000),
      maxLinks: Math.min(Math.max(Number(body.maxLinks) || 300, 1), 1000),
    });
    return response(200, result);
  } catch (error) {
    const message = error?.name === 'AbortError' ? 'Request timeout.' : (error?.message || 'Gagal mengambil assets.');
    const status = /wajib|harus|kredensial|lokal|private|terlalu banyak|bukan halaman/i.test(message) ? 400 : 502;
    return response(status, { success: false, error: message });
  }
}
