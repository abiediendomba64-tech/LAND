export default async function handler() {
  return {
    statusCode: 200,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    body: JSON.stringify({ status: 'ok', service: 'LAND', serverTime: new Date().toISOString() }),
  };
}
