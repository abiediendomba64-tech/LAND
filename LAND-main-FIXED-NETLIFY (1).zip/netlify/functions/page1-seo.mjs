import { GoogleGenAI } from '@google/genai';

const fallback = (input = {}) => {
  const brand = String(input.brandName || 'VIP OFFICIAL').trim() || 'VIP OFFICIAL';
  const keyword = String(input.targetKeyword || 'Slot Gacor Hari Ini').trim() || 'Slot Gacor Hari Ini';
  const deposit = String(input.minDeposit || 'Rp 10.000');
  const rtp = String(input.rtpRate || '98.8%');
  const url = String(input.targetUrl || '').trim();
  const title = `${brand} - ${keyword} | Informasi Resmi`;
  const description = `Informasi ${keyword} dari ${brand}, termasuk detail layanan, cara akses, dan informasi terbaru.`;
  const faqItems = [
    { question: `Apa itu ${keyword}?`, answer: `Halaman ini menyediakan informasi terkait ${keyword} dari ${brand}.` },
    { question: `Berapa minimal deposit yang tercantum?`, answer: `Informasi yang diberikan menggunakan nilai ${deposit}.` },
    { question: `Di mana melihat informasi terbaru?`, answer: `Gunakan halaman resmi ${brand} dan periksa informasi yang diperbarui secara berkala.` },
  ];
  return {
    page1Title: title,
    metaDescription: description,
    lsiKeywords: [keyword, brand, 'informasi resmi', 'panduan akses'],
    seoHeading: `${keyword} - Informasi ${brand}`,
    seoParagraph: `Halaman ini menyajikan informasi terstruktur mengenai ${keyword} untuk membantu pengunjung memahami layanan, navigasi, dan informasi penting secara jelas. Gunakan sumber resmi ${brand} sebagai rujukan dan periksa detail sebelum mengambil keputusan.`,
    faqItems,
    jsonLdSchema: {
      '@context': 'https://schema.org',
      '@type': input.schemaType === 'FAQPage' ? 'FAQPage' : 'WebPage',
      name: title,
      description,
      ...(url ? { url } : {}),
      ...(input.schemaType === 'FAQPage' ? {
        mainEntity: faqItems.map(item => ({
          '@type': 'Question',
          name: item.question,
          acceptedAnswer: { '@type': 'Answer', text: item.answer },
        })),
      } : {}),
    },
    trendingTopics: [keyword, 'informasi terbaru', 'panduan resmi', 'FAQ'],
    rtpReference: rtp,
  };
};

function json(statusCode, body) {
  return {
    statusCode,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
    body: JSON.stringify(body),
  };
}

export default async function handler(event) {
  if (event.httpMethod !== 'POST') return json(405, { success: false, error: 'Method not allowed' });
  try {
    const input = JSON.parse(event.body || '{}');
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) return json(200, { success: true, source: 'fallback', data: fallback(input) });

    const ai = new GoogleGenAI({ apiKey });
    const prompt = `Create a useful, factual SEO content package as valid JSON only.
Brand: ${input.brandName || 'Brand'}
Keyword: ${input.targetKeyword || 'Main topic'}
Niche: ${input.niche || 'General'}
Schema type: ${input.schemaType || 'WebPage'}
Canonical URL: ${input.targetUrl || ''}
Return keys: page1Title, metaDescription, lsiKeywords, seoHeading, seoParagraph, faqItems, jsonLdSchema, trendingTopics.
Do not claim rankings, licenses, guarantees, real-time statistics, or other facts that were not provided.`;

    const result = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: prompt,
    });
    const text = String(result.text || '').replace(/```json/gi, '').replace(/```/g, '').trim();
    const data = JSON.parse(text);
    return json(200, { success: true, source: 'gemini', data });
  } catch (error) {
    console.error('page1-seo:', error);
    return json(200, { success: true, source: 'fallback', data: fallback(JSON.parse(event.body || '{}')) });
  }
}
